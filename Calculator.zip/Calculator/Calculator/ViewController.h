//
//  ViewController.h
//  Calculator
//
//  Created by 
//Allison Crouch and Carter Mann on 1/20/15.
//  Copyright (c) 2015 CSCI448
//Allison Crouch and Carter Mann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *display;
@property (weak, nonatomic) IBOutlet UILabel *record;

@end

